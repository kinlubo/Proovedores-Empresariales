package com.example.Proveedores_Empresariales.City;

import com.example.Proveedores_Empresariales.Departament.Departament;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryCity extends JpaRepository<City,Integer> {
}
