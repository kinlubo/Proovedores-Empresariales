package com.example.Proveedores_Empresariales;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProveedoresEmpresarialesApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProveedoresEmpresarialesApplication.class, args);
	}

}
