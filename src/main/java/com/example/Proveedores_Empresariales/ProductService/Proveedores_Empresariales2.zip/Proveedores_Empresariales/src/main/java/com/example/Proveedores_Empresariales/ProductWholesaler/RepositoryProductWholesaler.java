package com.example.Proveedores_Empresariales.ProductWholesaler;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryProductWholesaler extends JpaRepository<ProductWholesaler,Integer> {
}
