package com.example.Proveedores_Empresariales.Departament;

import com.example.Proveedores_Empresariales.Country.Country;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryDepartment extends JpaRepository<Departament,Integer> {
}
