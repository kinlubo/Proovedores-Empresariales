package com.example.Proveedores_Empresariales.ProductService;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryProductService extends JpaRepository<ProductService,Integer> {
}
