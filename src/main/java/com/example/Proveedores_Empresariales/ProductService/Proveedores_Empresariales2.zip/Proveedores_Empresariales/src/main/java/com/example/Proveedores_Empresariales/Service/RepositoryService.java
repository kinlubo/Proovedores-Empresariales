package com.example.Proveedores_Empresariales.Service;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryService extends JpaRepository<Service,Integer> {
}
