package com.example.Proveedores_Empresariales.Country;

import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryCountry extends JpaRepository<Country,Integer> {
}
