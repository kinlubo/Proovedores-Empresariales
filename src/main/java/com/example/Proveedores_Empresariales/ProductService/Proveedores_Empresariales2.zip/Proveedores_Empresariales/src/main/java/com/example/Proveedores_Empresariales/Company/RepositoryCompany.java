package com.example.Proveedores_Empresariales.Company;

import com.example.Proveedores_Empresariales.City.City;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RepositoryCompany extends JpaRepository<Company,Integer> {
}
